# Moamen

## Download Latest Android APK

Open the **Releases** panel on the top right of this repository and tap **Moamen.apk** under the **Latest** release to download and install on Android.

Every update pushed to `main` automatically builds and publishes a new **Latest** release.
